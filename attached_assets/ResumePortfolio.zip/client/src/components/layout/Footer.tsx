import resumeData from '@/data/resumeData';

const Footer = () => {
  const { name, title, email } = resumeData;
  
  return (
    <footer className="bg-dark text-white py-8 no-print">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h2 className="text-xl font-roboto font-bold">{name}</h2>
            <p className="text-gray-light text-sm mt-1">{title}</p>
          </div>
          
          <div className="flex gap-4">
            <a href={resumeData.linkedin} target="_blank" rel="noopener noreferrer" className="text-gray-light hover:text-white transition-colors">
              <i className="ri-linkedin-fill text-xl"></i>
            </a>
            <a href={resumeData.github} target="_blank" rel="noopener noreferrer" className="text-gray-light hover:text-white transition-colors">
              <i className="ri-github-fill text-xl"></i>
            </a>
            <a href={`mailto:${email}`} className="text-gray-light hover:text-white transition-colors">
              <i className="ri-mail-fill text-xl"></i>
            </a>
          </div>
        </div>
        
        <div className="mt-6 pt-6 border-t border-gray-dark text-center text-gray-light text-sm">
          <p>&copy; {new Date().getFullYear()} {name}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
