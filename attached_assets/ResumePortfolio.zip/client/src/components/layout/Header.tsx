import { useState, useEffect } from 'react';
import { scrollToElement } from '@/lib/utils';

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (sectionId: string) => {
    scrollToElement(sectionId);
    setMobileMenuOpen(false);
  };

  return (
    <header className={`bg-white shadow-md sticky top-0 z-50 no-print transition-all ${scrolled ? 'py-2' : 'py-3'}`}>
      <div className="container mx-auto px-4 flex justify-between items-center">
        <h1 className="text-xl font-roboto font-bold text-primary">Zaeem Uz Zafar</h1>
        <nav className="hidden md:flex space-x-6">
          <button 
            onClick={() => handleNavClick('about')} 
            className="font-medium hover:text-primary transition-colors"
          >
            About
          </button>
          <button 
            onClick={() => handleNavClick('experience')} 
            className="font-medium hover:text-primary transition-colors"
          >
            Experience
          </button>
          <button 
            onClick={() => handleNavClick('education')} 
            className="font-medium hover:text-primary transition-colors"
          >
            Education
          </button>
          <button 
            onClick={() => handleNavClick('skills')} 
            className="font-medium hover:text-primary transition-colors"
          >
            Skills
          </button>
          <button 
            onClick={() => handleNavClick('portfolio')} 
            className="font-medium hover:text-primary transition-colors"
          >
            Portfolio
          </button>
          <button 
            onClick={() => handleNavClick('contact')} 
            className="font-medium hover:text-primary transition-colors"
          >
            Contact
          </button>
        </nav>
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)} 
          className="md:hidden text-dark hover:text-primary"
          aria-label="Toggle mobile menu"
        >
          <i className={`ri-${mobileMenuOpen ? 'close' : 'menu'}-line text-2xl`}></i>
        </button>
      </div>
      
      {/* Mobile menu */}
      <div 
        className={`md:hidden bg-white shadow-lg absolute w-full transition-all duration-300 ease-in-out ${
          mobileMenuOpen ? 'max-h-64 opacity-100' : 'max-h-0 opacity-0 overflow-hidden'
        }`}
      >
        <div className="container mx-auto px-4 py-3 flex flex-col space-y-3">
          <button 
            onClick={() => handleNavClick('about')} 
            className="font-medium py-2 hover:text-primary transition-colors text-left"
          >
            About
          </button>
          <button 
            onClick={() => handleNavClick('experience')} 
            className="font-medium py-2 hover:text-primary transition-colors text-left"
          >
            Experience
          </button>
          <button 
            onClick={() => handleNavClick('education')} 
            className="font-medium py-2 hover:text-primary transition-colors text-left"
          >
            Education
          </button>
          <button 
            onClick={() => handleNavClick('skills')} 
            className="font-medium py-2 hover:text-primary transition-colors text-left"
          >
            Skills
          </button>
          <button 
            onClick={() => handleNavClick('portfolio')} 
            className="font-medium py-2 hover:text-primary transition-colors text-left"
          >
            Portfolio
          </button>
          <button 
            onClick={() => handleNavClick('contact')} 
            className="font-medium py-2 hover:text-primary transition-colors text-left"
          >
            Contact
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
