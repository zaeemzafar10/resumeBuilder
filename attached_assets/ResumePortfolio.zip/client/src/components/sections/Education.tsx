import resumeData from '@/data/resumeData';

const Education = () => {
  const { education, certifications } = resumeData;

  return (
    <section id="education" className="py-16 bg-gray-lightest">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-roboto font-bold text-dark mb-8 pb-2 border-b border-gray-light">
          <i className="ri-graduation-cap-line text-primary mr-2"></i> Education & Certifications
        </h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-roboto font-medium text-dark mb-2">Education</h3>
            <div className="relative pl-8 ml-4 space-y-8">
              {education.map((edu, index) => (
                <div key={index} className="timeline-item relative pl-6">
                  <h4 className="text-lg font-roboto font-medium text-dark">{edu.degree}</h4>
                  <div className="text-primary font-medium mb-1">{edu.institution}, {edu.location}</div>
                  <div className="text-gray-dark text-sm mb-3">{edu.period}</div>
                  <p className="text-gray-dark text-sm">{edu.description}</p>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-roboto font-medium text-dark mb-2">Certifications</h3>
            <div className="relative pl-8 ml-4 space-y-8">
              {certifications.map((cert, index) => (
                <div key={index} className="timeline-item relative pl-6">
                  <h4 className="text-lg font-roboto font-medium text-dark">{cert.name}</h4>
                  <div className="text-primary font-medium mb-1">{cert.issuer}</div>
                  <div className="text-gray-dark text-sm mb-2">{cert.period}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;
