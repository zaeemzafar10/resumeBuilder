import resumeData from '@/data/resumeData';

const Experience = () => {
  const { experiences } = resumeData;

  return (
    <section id="experience" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-roboto font-bold text-dark mb-8 pb-2 border-b border-gray-light">
          <i className="ri-briefcase-line text-primary mr-2"></i> Professional Experience
        </h2>
        
        <div className="relative pl-8 ml-4 space-y-10">
          {experiences.map((experience, index) => (
            <div key={index} className="timeline-item relative pl-6">
              <h3 className="text-xl font-roboto font-medium text-dark">{experience.title}</h3>
              <div className="text-primary font-medium mb-1 flex items-center gap-1 flex-wrap">
                <i className="ri-building-line"></i> {experience.company}
                <span className="text-gray-medium mx-1">|</span>
                <span className="text-gray-medium text-sm">{experience.location}</span>
              </div>
              <div className="text-gray-dark text-sm mb-3">{experience.period}</div>
              <p className="text-gray-dark mb-4">{experience.description}</p>
              <div className="flex flex-wrap gap-2">
                {experience.skills.map((skill, skillIndex) => (
                  <span key={skillIndex} className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-md">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;
