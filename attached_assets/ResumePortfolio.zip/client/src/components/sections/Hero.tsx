import { downloadResume } from '@/lib/utils';
import resumeData from '@/data/resumeData';
import { scrollToElement } from '@/lib/utils';
import zaeemPhoto from '../../../../public/assets/zaeemPhoto.jpeg';
import cover from '../../../../public/assets/ilya-pavlov-OqtafYT5kTw-unsplash.jpg';
const Hero = () => {
  const { name, title, summary } = resumeData;

  const handleDownload = (e: React.MouseEvent) => {
    e.preventDefault();
    downloadResume();
  };

  const handleContactClick = (e: React.MouseEvent) => {
    e.preventDefault();
    scrollToElement('contact');
  };

  return (
    <section id="about" className="pt-10 pb-16 md:py-20 relative overflow-hidden">
      {/* Abstract tech background */}
      <div className="absolute inset-0 z-0 opacity-10" 
           style={{
            backgroundImage: `url(${cover})`,
                  backgroundSize: 'cover', 
                  backgroundPosition: 'center'}}></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
          <div className="w-40 h-40 md:w-48 md:h-48 rounded-full overflow-hidden shadow-lg flex-shrink-0 border-4 border-white">
            {/* Professional headshot placeholder */}
            <img 
              src={zaeemPhoto} 
              alt={`${name} Profile`} 
              className="w-full h-full object-cover" 
            />
          </div>
          <div className="text-center md:text-left">
            <h1 className="text-3xl md:text-5xl font-roboto font-bold text-dark mb-2">{name}</h1>
            <h2 className="text-xl md:text-2xl font-roboto font-medium text-primary mb-4">{title}</h2>
            <p className="text-gray-dark max-w-2xl mb-6">{summary}</p>
            <div className="flex flex-wrap justify-center md:justify-start gap-3">
              <button 
                onClick={handleContactClick}
                className="bg-primary hover:bg-primary/90 text-white font-medium py-2 px-4 rounded-md transition-colors flex items-center gap-2"
              >
                <i className="ri-mail-line"></i> Contact Me
              </button>
              <button 
                onClick={handleDownload}
                className="bg-white hover:bg-gray-lightest text-dark border border-gray-light font-medium py-2 px-4 rounded-md transition-colors flex items-center gap-2"
              >
                <i className="ri-download-line"></i> Download CV
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
