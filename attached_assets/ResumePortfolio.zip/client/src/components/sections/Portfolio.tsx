import resumeData from '@/data/resumeData';

const Portfolio = () => {
  const { projects } = resumeData;

  return (
    <section id="portfolio" className="py-16 bg-gray-lightest">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-roboto font-bold text-dark mb-8 pb-2 border-b border-gray-light">
          <i className="ri-folder-open-line text-primary mr-2"></i> Portfolio Projects
        </h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
              <div className="h-48 overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover object-center hover:scale-105 transition-transform duration-300" 
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-roboto font-medium text-dark mb-2">{project.title}</h3>
                <p className="text-gray-dark mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech, techIndex) => (
                    <span key={techIndex} className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-md">
                      {tech}
                    </span>
                  ))}
                </div>
                <a 
                  href={project.link} 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-primary hover:text-primary/80 font-medium transition-colors"
                >
                  View Project <i className="ri-arrow-right-line"></i>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;