import resumeData from '@/data/resumeData';

const Skills = () => {
  const { technicalSkills, additionalSkills, languages, hobbies } = resumeData;

  return (
    <section id="skills" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-roboto font-bold text-dark mb-8 pb-2 border-b border-gray-light">
          <i className="ri-tools-line text-primary mr-2"></i> Skills & Expertise
        </h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-roboto font-medium text-dark mb-4">Technical Skills</h3>
            <div className="space-y-5">
              {technicalSkills.map((skill, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-1">
                    <span className="font-medium text-gray-dark">{skill.name}</span>
                    <span className="text-primary text-sm">{skill.level}</span>
                  </div>
                  <div className="w-full bg-gray-lightest rounded-full h-2.5">
                    <div 
                      className="bg-primary h-2.5 rounded-full" 
                      style={{ width: `${skill.percentage}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-roboto font-medium text-dark mb-4">Additional Skills</h3>
            <div className="flex flex-wrap gap-3">
              {additionalSkills.map((skill, index) => (
                <span key={index} className="px-3 py-2 bg-gray-lightest text-gray-dark rounded-md flex items-center gap-1.5">
                  <i className="ri-checkbox-circle-line text-primary"></i>
                  <span>{skill}</span>
                </span>
              ))}
            </div>
            
            <h3 className="text-xl font-roboto font-medium text-dark mt-8 mb-4">Languages</h3>
            <div className="flex flex-wrap gap-3">
              {languages.map((language, index) => (
                <span key={index} className="px-3 py-2 bg-gray-lightest text-gray-dark rounded-md">
                  {language}
                </span>
              ))}
            </div>
            
            <h3 className="text-xl font-roboto font-medium text-dark mt-8 mb-4">Hobbies & Interests</h3>
            <div className="flex flex-wrap gap-3">
              {hobbies.map((hobby, index) => (
                <span key={index} className="px-3 py-2 bg-gray-lightest text-gray-dark rounded-md flex items-center gap-1.5">
                  <i className={`${hobby.icon} text-primary`}></i>
                  <span>{hobby.name}</span>
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
