export interface Experience {
  title: string;
  company: string;
  location: string;
  period: string;
  description: string;
  skills: string[];
}

export interface Education {
  degree: string;
  institution: string;
  location: string;
  period: string;
  description: string;
}

export interface Certification {
  name: string;
  issuer: string;
  period: string;
}

export interface Skill {
  name: string;
  level: string;
  percentage: number;
}

export interface Project {
  title: string;
  description: string;
  technologies: string[];
  image: string;
  link: string;
}

export interface ResumeData {
  name: string;
  title: string;
  summary: string;
  location: string;
  email: string;
  phone: string;
  linkedin: string;
  github: string;
  experiences: Experience[];
  education: Education[];
  certifications: Certification[];
  technicalSkills: Skill[];
  additionalSkills: string[];
  languages: string[];
  hobbies: { icon: string; name: string }[];
  projects: Project[];
}

const resumeData: ResumeData = {
  name: "Zaeem Uz Zafar",
  title: "Backend Engineer",
  summary: "Experienced backend engineer specializing in MERN and PERN stack development with expertise in Node.js, Express, MongoDB, PostgreSQL, and React.js. Proficient in building real-time applications with WebSockets and implementing RESTful APIs.",
  location: "Karachi, Pakistan",
  email: "zafarzaeemmern@gmail.com",
  phone: "03343338690",
  linkedin: "https://linkedin.com/in/zaeem-uz-zafar", // Example LinkedIn URL 
  github: "https://github.com/zafarzaeem12", // Example GitHub URL
  experiences: [
    {
      title: "Backend Engineer",
      company: "Salsoft Pvt Ltd",
      location: "Karachi",
      period: "May 2024 — Present",
      description: "Working on MERN and PERN stack backend tech Node.js using framework Express.js with NoSQL and SQL (MongoDB and PostgreSQL) databases using Mongoose and Prisma ORM. Worked on HTTP and WebSocket for real-time applications, working on frontend React.js API integration on multiple dashboards and websites.",
      skills: ["Node.js", "Express.js", "MongoDB", "PostgreSQL", "Prisma", "WebSockets"]
    },
    {
      title: "Backend Developer",
      company: "Jumpace Pvt Ltd",
      location: "Karachi",
      period: "August 2023 — May 2024",
      description: "Working on MERN stack backend tech Node.js using framework Express.js with NoSQL MongoDB database using Mongoose ORM. Worked on HTTP and WebSocket for real-time applications, working on frontend React.js API integration on multiple dashboards and websites.",
      skills: ["Node.js", "Express.js", "MongoDB", "Mongoose", "WebSockets"]
    },
    {
      title: "Software Engineer",
      company: "Binate Digital",
      location: "Karachi",
      period: "May 2022 — August 2023",
      description: "Working on MERN stack backend tech Node.js using framework Express.js with NoSQL MongoDB database using Mongoose ORM. Working on frontend React.js API integration on multiple dashboards and websites.",
      skills: ["Node.js", "Express.js", "MongoDB", "Mongoose", "React.js"]
    },
    {
      title: "Jr MERN Developer",
      company: "MiniBig Technology",
      location: "Karachi",
      period: "August 2021 — April 2022",
      description: "Worked on React.js for HTTP and third-party API integrations in frontend only.",
      skills: ["React.js", "API Integration"]
    }
  ],
  education: [
    {
      degree: "Bachelor in Software Engineering",
      institution: "Hamdard University",
      location: "Karachi",
      period: "January 2017 — March 2021",
      description: "Completed Software Engineering degree in 2021"
    },
    {
      degree: "Master in Cyber Security",
      institution: "N.E.D University",
      location: "Karachi",
      period: "January 2025 — March 2027",
      description: "Continue master degree in 2027"
    }
  ],
  certifications: [
    {
      name: "MERN Stack",
      issuer: "Udemy",
      period: "July 2022 — November 2024"
    },
    {
      name: "React",
      issuer: "Udemy",
      period: "January 2021 — February 2024"
    },
    {
      name: "Javascript and Ecmascript",
      issuer: "Udemy",
      period: "January 2020 — April 2020"
    }
  ],
  technicalSkills: [
    {
      name: "JavaScript",
      level: "Advanced",
      percentage: 90
    },
    {
      name: "Node.js",
      level: "Advanced",
      percentage: 90
    },
    {
      name: "Express.js",
      level: "Advanced",
      percentage: 85
    },
    {
      name: "React.js",
      level: "Intermediate",
      percentage: 75
    },
    {
      name: "MongoDB",
      level: "Advanced",
      percentage: 85
    }
  ],
  additionalSkills: [
    "Redux",
    "PostgreSQL",
    "Prisma",
    "Mongoose",
    "Web Sockets",
    "API Integrations",
    "Heroku",
    "Cpanel",
    "Git"
  ],
  languages: ["English", "Urdu"],
  hobbies: [
    { icon: "ri-book-open-line", name: "Learning" },
    { icon: "ri-road-map-line", name: "Long Drives" },
    { icon: "ri-compass-3-line", name: "Adventures" }
  ],
  projects: [
    {
      title: "Predivauth Marketplace",
      description: "A marketplace platform for buying and selling products with user authentication, product listings, and payment integration.",
      technologies: ["Node.js", "Express", "MongoDB", "React", "Redux", "WebSockets"],
      image: "https://srv4.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-iKsF18b7huTRYiA.jpg",
      link: "https://predivauthmarketplace.com"
    },
    {
      title: "Predivauth Vendor Dasbhboard",
      description: "A marketplace platform for buying and selling products with user authentication, product listings, and payment integration.",
      technologies: ["Node.js", "Express", "MongoDB", "React", "Redux", "WebSockets"],
      image: "https://www.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-2484ehhTa2T.jpg",
      link: "https://predivauthmarketplace.com/vendor"
    },
    {
      title: "Predivauth Admin Dasbhboard",
      description: "A marketplace platform for buying and selling products with user authentication, product listings, and payment integration.",
      technologies: ["Node.js", "Express", "MongoDB", "React", "Redux", "WebSockets"],
      image: "https://srv2.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-USqMeNQ1Z8t3.jpg",
      link: "https://predivauthmarketplace.com/admin"
    },
    {
      title: "Instapet",
      description: "its a Pet transportation webApplication for booking and tracking pet transportation services.",
      technologies: ["Node.js", "Express", "MongoDB", "React", "Redux", "WebSockets"],
      image: "https://www.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-dMYQswfOhQtxX.jpg",
      link: "https://instapet.co"
    },
    {
      title: "Instapet Driver Dasbhboard",
      description: "driver dashboard transportation webApplication for tracking pet transportation services.",
      technologies: ["Node.js", "Express", "MongoDB", "React", "Redux", "WebSockets"],
      image: "https://srv2.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-dBFj7tGAgIZ9.jpg",
      link: "https://instapet.co/driver"
    },
    {
      title: "Instapet Admin Dasbhboard",
      description: "admin dashboard transportation webApplication for tracking pet transportation services and intiall paymnets.",
      technologies: ["Node.js", "Express", "MongoDB", "React", "Redux", "WebSockets"],
      image: "https://srv2.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-dBFj7tGAgIZ9.jpg",
      link: "https://instapet.co/admin"
    },
    {
      title: "Dog Care",
      description: "its a web base application for pet's care.",
      technologies: ["Node.js", "Express", "MongoDB", "React", "Redux", "WebSockets"],
      image: "https://srv4.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-5DirVNuD3A.jpg ",
      link: "https://react.customdev.solutions/dogcare"
    },
    {
      title: "Dog Care Employee Dasbhboard",
      description: "its a web base application for pet's care. employees dasboard.",
      technologies: ["Node.js", "Express", "MongoDB", "React", "Redux", "WebSockets"],
      image: "https://srv2.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-BPypFhywdWDSCt.jpg",
      link: "https://react.customdev.solutions/dogcare/employee"
    },
    {
      title: "Dog Care Admin Dasbhboard",
      description: "its a web base application for pet's care. admin dasboard.",
      technologies: ["Node.js", "Express", "MongoDB", "React", "Redux", "WebSockets"],
      image: "https://srv2.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-BPypFhywdWDSCt.jpg",
      link: "https://react.customdev.solutions/dogcare/admin"
    },
    {
      title: "Parvin Dating App",
      description: "its dating mobile app for finding love and connections.",
      technologies: ["Node.js", "Express", "MongoDB", "WebSockets", "React", "Socket.IO"],
      image: "https://srv4.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-BfT472TnpuyQMCS.jpg",
      link: "https://play.google.com/store/apps/details?id=com.parvindatingapp&hl=en"
    },
    {
      title: "Parvin Admin Dasbhboard",
      description: "its a dating app admin dasboard.",
      technologies: ["Node.js", "Express", "PostgreSQL", "Prisma", "React", "TypeScript"],
      image: "https://srv4.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-BfT472TnpuyQMCS.jpg",
      link: "https://react.customdev.solutions/parvin/admin/signin"
    },
    {
      title: "GoldenLove Dating App",
      description: "its a dating app for finding love and connections.",
      technologies: ["Node.js", "Express", "MongoDB", "WebSockets", "React", "Socket.IO"],
      image: "https://srv4.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-GYmviEv5YCUzX46.jpg",
      link: "https://goldenloveconnections.com"
    },
    {
      title: "GoldenLove Admin Dasbhboard",
      description: "its a dating app for finding love and connections. controlling app behavior",
      technologies: ["Node.js", "Express", "PostgreSQL", "Prisma", "React", "TypeScript"],
      image: "https://srv2.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-Nok7w6uXlUC.jpg",
      link: "https://goldenloveconnections.com/admin"
    },
    {
      title: "Laundry App",
      description: "its a laundry wash webApplication for booking and tracking laundry services.",
      technologies: ["Node.js", "Express", "MongoDB", "Mongoose", "React", "JWT"],
      image: "https://srv2.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-eAqy9HyuKOLZH.jpg",
      link: "https://react.customdev.solutions/laundry/"
    },
    {
      title: "Laundry Admin Dasbhboard",
      description: "its a admin dasboard for laundry wash webApplication for booking and tracking laundry services.",
      technologies: ["Node.js", "Express", "MongoDB", "Mongoose", "React", "JWT"],
      image: "https://srv2.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-5GK34jXuLhzOpnwa.jpg",
      link: "https://react.customdev.solutions/laundry/admin"
    },
    {
      title: "Cry o Guys App",
      description: "its an offline app for survey's.",
      technologies: ["Node.js", "Express", "PostgreSQL", "Prisma", "React", "TypeScript"],
      image: "https://srv4.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-LcuZw9xrEp4p4N.jpg",
      link: "https://play.google.com/store/apps/details?id=com.cryoguys&hl=en"
    },
    {
      title: "Cry o Guys Franchise Dasbhboard",
      description: "its an offline app for survey's franshise dashboard.",
      technologies: ["Node.js", "Express", "MongoDB", "WebSockets", "React", "Socket.IO"],
      image: "https://srv4.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-LcuZw9xrEp4p4N.jpg",
      link: "https://react.customdev.solutions/cryo-guys/admin/signin"
    },
    {
      title: "Cry o Guys Admin Dasbhboard",
      description: "its an offline app for survey's admin dashboard.",
      technologies: ["Node.js", "Express", "PostgreSQL", "Prisma", "React", "TypeScript"],
      image: "https://srv4.imgonline.com.ua/result_img/imgonline-com-ua-twotoone-LcuZw9xrEp4p4N.jpg",
      link: "https://react.customdev.solutions/cryo-guys/superadmin/signin"
    },
  ]
};

export default resumeData;
