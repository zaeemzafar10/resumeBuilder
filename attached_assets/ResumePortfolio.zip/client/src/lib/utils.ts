import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Handle resume download
export function downloadResume() {
  // Create a link to trigger the download
  const link = document.createElement('a');
  link.href = '/assets/Zaeem_Uz_Zafar_Resume.pdf';
  link.download = 'Zaeem_Uz_Zafar_Resume.pdf';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Smooth scroll to element
export function scrollToElement(elementId: string) {
  const element = document.getElementById(elementId);
  if (element) {
    window.scrollTo({
      top: element.offsetTop - 70,
      behavior: 'smooth'
    });
    return true;
  }
  return false;
}
