import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Set title
document.title = "Zaeem Uz Zafar - Backend Engineer";

createRoot(document.getElementById("root")!).render(<App />);
