import { Request, Response } from 'express';
import Contact from '../models/Contact';
import { sendContactNotification, sendAutoReply } from '../utils/emailService';

// Controller to handle contact form submissions
export const submitContactForm = async (req: Request, res: Response) => {
  try {
    const { name, email, subject, message } = req.body;

    // Validate request body
    if (!name || !email || !subject || !message) {
      return res.status(400).json({ 
        success: false, 
        message: 'Please provide all required fields (name, email, subject, message)' 
      });
    }

    // Create new contact entry
    const newContact = new Contact({
      name,
      email,
      subject,
      message
    });

    // Save to database
    const savedContact = await newContact.save();

    // Send email notification to admin
    const notificationResult = await sendContactNotification({
      name,
      email,
      subject,
      message
    });

    // Send auto-reply to the sender
    const autoReplyResult = await sendAutoReply({
      name,
      email
    });

    // Return success response
    return res.status(201).json({
      success: true,
      message: 'Contact form submitted successfully',
      data: savedContact,
      emailNotification: notificationResult.success,
      autoReply: autoReplyResult.success
    });
  } catch (error) {
    console.error('Error submitting contact form:', error);
    return res.status(500).json({
      success: false,
      message: 'An error occurred while submitting the contact form',
      error: error instanceof Error ? error.message : String(error)
    });
  }
};