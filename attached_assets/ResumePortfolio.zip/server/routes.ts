import type { Express } from "express";
import { createServer, type Server } from "http";
import express from "express";
import path from "path";
import { storage } from "./storage";
import { connectDB } from "./utils/db";
import contactRoutes from "./routes/contactRoutes";

export async function registerRoutes(app: Express): Promise<Server> {
  // Connect to MongoDB
  await connectDB();

  // Serve static files from the public directory
  app.use('/assets', express.static(path.join(process.cwd(), 'public/assets')));

  // API routes
  app.use('/api/contact', contactRoutes);

  // use storage to perform CRUD operations on the storage interface
  // e.g. storage.insertUser(user) or storage.getUserByUsername(username)

  const httpServer = createServer(app);

  return httpServer;
}
