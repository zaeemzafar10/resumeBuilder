import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Create a transporter object using SMTP transport
const transporter = nodemailer.createTransport({
  host: process.env.MAIL_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.MAIL_PORT || '587'),
  secure: process.env.MAIL_ENCRYPTION === 'ssl', // true for 465, false for other ports
  auth: {
    user: process.env.MAIL_USERNAME,
    pass: process.env.MAIL_PASSWORD
  },
  // Additional options to improve deliverability
  tls: {
    rejectUnauthorized: false // Accept self-signed certificates
  },
  pool: true, // Use connection pooling
  maxConnections: 5,
  maxMessages: 100
});

// Function to send an email notification when a new contact form is submitted
export const sendContactNotification = async (contact: { 
  name: string; 
  email: string; 
  subject: string; 
  message: string; 
}) => {
  try {
    // Email content with improved headers and content
    const mailOptions = {
      from: `"Zaeem's Resume Website" <${process.env.MAIL_FROM_ADDRESS}>`,
      to: "zafarzaeemmern@gmail.com", // Send to Zaeem's email
      replyTo: contact.email, // Makes it easy to reply directly to the sender
      subject: `Website Contact Form: ${contact.subject}`,
      text: `Name: ${contact.name}\nEmail: ${contact.email}\nSubject: ${contact.subject}\n\nMessage:\n${contact.message}`, // Plain text version
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>New Contact Form Message</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #3b82f6; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9f9f9; }
            .footer { font-size: 12px; text-align: center; color: #666; padding: 10px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h2>New Contact Form Message</h2>
            </div>
            <div class="content">
              <p>You have received a new message from your website contact form:</p>
              <p><strong>Name:</strong> ${contact.name}</p>
              <p><strong>Email:</strong> <a href="mailto:${contact.email}">${contact.email}</a></p>
              <p><strong>Subject:</strong> ${contact.subject}</p>
              <p><strong>Message:</strong></p>
              <p>${contact.message.replace(/\n/g, '<br>')}</p>
            </div>
            <div class="footer">
              <p>This message was sent from your resume website's.</p>
            </div>
          </div>
        </body>
        </html>
      `,
      headers: {
        'X-Priority': '1', // Higher priority
        'X-MSMail-Priority': 'High',
        'Importance': 'High',
        'X-Contact-Form': 'Zaeem-Resume-Website' // Custom header
      }
    };

    // Send the email
    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent:', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('Error sending email:', error);
    return { success: false, error };
  }
};

// Function to send an auto-reply to the person who submitted the form
export const sendAutoReply = async (contact: { 
  name: string; 
  email: string; 
}) => {
  try {
    // Email content for auto-reply with improved formatting
    const mailOptions = {
      from: `"Zaeem Uz Zafar" <${process.env.MAIL_FROM_ADDRESS}>`,
      to: contact.email,
      subject: 'Thank you for your message',
      text: `Hello ${contact.name},\n\nThank you for reaching out. I have received your message and will get back to you as soon as possible.\n\nBest Regards,\nZaeem Uz Zafar\nBackend Engineer`, // Plain text version
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Thank You for Your Message</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #3b82f6; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9f9f9; }
            .footer { font-size: 12px; text-align: center; color: #666; padding: 10px; }
            .signature { margin-top: 20px; border-top: 1px solid #eee; padding-top: 10px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h2>Thank You for Your Message</h2>
            </div>
            <div class="content">
              <p>Hello ${contact.name},</p>
              <p>Thank you for reaching out through my website. I have received your message and will get back to you as soon as possible.</p>
              <p>In the meantime, feel free to explore more of my work and experience on my website.</p>
              <div class="signature">
                <p>Best Regards,</p>
                <p><strong>Zaeem Uz Zafar</strong><br>
                Backend Engineer</p>
              </div>
            </div>
            <div class="footer">
              <p>This is an automated response from my resume website's contact form.</p>
            </div>
          </div>
        </body>
        </html>
      `,
      headers: {
        'X-Priority': '1',
        'X-MSMail-Priority': 'High',
        'Importance': 'High'
      }
    };

    // Send the auto-reply
    const info = await transporter.sendMail(mailOptions);
    console.log('Auto-reply sent:', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('Error sending auto-reply:', error);
    return { success: false, error };
  }
};